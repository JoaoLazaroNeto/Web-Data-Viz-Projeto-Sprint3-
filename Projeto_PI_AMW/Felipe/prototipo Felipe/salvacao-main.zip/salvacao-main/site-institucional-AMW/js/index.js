scrip

    function analisar() {
        var quantidadeobras = Number(input_quantidadeobras.value);
        var custoMedio = Number(input_custoMedio.value);
        var estacao = input_estacao.value;
        var regiao = input_regiao.value;
        var nome = input_nome.value;

        var umidade = 0;

        var valorTotal = quantidadeobras * custoMedio;
        var valorPerdido = (valorTotal * 0.40);

        if (regiao == "centro-oeste") {
        if (estacao == "verão") {
            umidade = 56;
        }
        if (estacao == "outono") {
           umidade = 75;
           valorPerdido = valorPerdido + 350;
        }
        if (estacao == "inverno") {
            umidade = 61;
        }
        if (estacao == "primavera") {
            umidade = 67.5;
        } 
    }


        if (regiao == "norte") {

        if (estacao == "verão") {
            umidade = 72.5;
            valorPerdido = valorPerdido + 300;
        }
        if (estacao == "outono") {
          umidade = 69.25;
        }
        if (estacao == "inverno") {
            umidade = 51.75;
        }
        if (estacao == "primavera") {
            umidade = 66.5;
        }
    }


        if (regiao == "sudeste") {

        if (estacao == "verão") {
            umidade = 70;
            valorPerdido = valorPerdido + 300;
        }
        if (estacao == "outono") {
            umidade = 68;
        }
        if (estacao == "inverno") {
            umidade = 58.75;
        }
        if (estacao == "primavera") {
            umidade = 66.25;
        }
    }

    
        if (regiao == "sul") {
        
        if (estacao == "verão") {
            umidade = 77.7;
            valorPerdido = valorPerdido + 370;
        }
        if (estacao == "outono") {
            umidade = 75;
            valorPerdido = valorPerdido + 350;
        }
        if (estacao == "inverno") {
            umidade = 74.25;
            valorPerdido = valorPerdido + 340;
        }
        if (estacao == "primavera") {
            umidade = 76;
            valorPerdido = valorPerdido + 360;
        }
        }


        if (regiao == "nordeste") {

        if (estacao == "verão") {
            umidade = 77;
            valorPerdido = valorPerdido + 370;
        }
        if (estacao == "outono") {
            umidade = 76;
            valorPerdido = valorPerdido + 360;
        }
        if (estacao == "inverno") {
            umidade = 65;
        }
        if (estacao == "primavera") {
            umidade = 61;
        }
    }


    divSome.style.display = "none";
    divRespostaInvisivel.style.display = "flex";

    div_msg.innerHTML = ` Olá ${nome}! Na região ${regiao} durante a estação ${estacao} a porcentagem média de umidade é ${umidade}%`
    div_msg.innerHTML += `<br> Nessas condições você pode ter um prejuízo estimado de R$${valorPerdido}<br> Com nosso sistema você pode reduzir esse prejúizo em até 40%`;


}
